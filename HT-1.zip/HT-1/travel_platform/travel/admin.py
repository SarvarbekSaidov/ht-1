from django.contrib import admin
from .models import Destination, Tour, Review, Booking

# Register your models here.

class DestinationAdmin(admin.ModelAdmin):
    list_display = ('name', 'country', 'city', 'image')

class TourAdmin(admin.ModelAdmin):
    list_display = ('name', 'destination', 'price', 'duration')

admin.site.register(Destination, DestinationAdmin)
admin.site.register(Tour, TourAdmin)
admin.site.register(Review)
admin.site.register(Booking)
