from django import template

register = template.Library()

@register.simple_tag
def greeting(name):
    return f"Hi there, {name}!"

@register.simple_tag
def special_message(destination):
    messages = {
        'Paris': 'The city of lights&amore awaits you!',
        'Tokyo': 'Experience the blend of tradition and modernity!',
    }
    return messages.get(destination.name, 'Discover the wonders of this destination!')
