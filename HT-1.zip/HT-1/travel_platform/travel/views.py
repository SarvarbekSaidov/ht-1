from django.shortcuts import render
from .models import Tour

# Create your views here.
def home(request):
    return render(request, 'home.html')

def destinations(request):
    return render(request, 'destinations.html')

def tours(request):
    tours = Tour.objects.all()
    return render(request, 'tours.html', {'tours': tours})

def bookings(request):
    return render(request, 'bookings.html')
