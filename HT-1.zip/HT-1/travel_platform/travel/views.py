from django.shortcuts import render
from .models import Tour, Booking, Destination



# Create your views here.
def home(request):
    return render(request, 'home.html')

def destinations(request):
    destinations = Destination.objects.all()
    return render(request, 'destinations.html', {'destinations': destinations})

def tours(request):
    tours = Tour.objects.all()
    return render(request, 'tours.html', {'tours': tours})

def bookings(request):
    bookings = Booking.objects.all()
    return render(request, 'bookings.html', {'bookings': bookings})
